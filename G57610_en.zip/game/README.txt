
title:      Dominator

authors:    Omer Giménez
            Jordi Petit
	    Enric Rodríguez
            Salvador Roura
	    Albert Vaca

contact:    jpetit@cs.upc.edu

(c) Universitat Politècnica de Catalunya, 2016
