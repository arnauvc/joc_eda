#include "Utils.hh"

// To deactivate standard sleep function.
unsigned int sleep(unsigned int seconds) {
  return 0;
}
